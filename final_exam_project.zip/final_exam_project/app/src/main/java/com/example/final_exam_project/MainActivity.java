package com.example.final_exam_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    String continents[] = {"Choose continent", "North America", "South America", "Europe", "Asia"};
    String countries[][] = {
            { "...", "USA", "Canada" },
            { "...", "Brazil", "Colombia" },
            { "...", "Germany", "France"},
            { "...", "Vietnam", "India" }
    };

    String statistics[][] = {
            {"16,993,506", "6,793,297", "309,046", "9,891,163"},
            {"472,885", "76,428", "13,611", "382,846"},
            {"6,934,539", "736,476", "181,978", "6,016,085"},
            {"1,434,516", "73,852", "39,195", "1,321,469"},
            {"1,371,198", "344,607", "23,291", "1,003,300"},
            {"2,379,915", "2,143,986", "58,282", "177,647"},
            {"1,405", "118", "35", "1,252"},
            {"9,930,284", "334,563", "144,075", "9,451,646"}
    };

    Spinner continent_spinner;
    Spinner country_spinner;

    public void move_to_covid_19_data(String statistic[], String country_name) {
        Intent intent = new Intent(this, Covid_19_Data.class);
        String get_total_cases = statistic[0];
        String get_active_cases = statistic[1];
        String get_total_death = statistic[2];
        String get_recovered_cases = statistic[3];
        intent.putExtra("country_name", country_name);
        intent.putExtra("total_case", get_total_cases);
        intent.putExtra("active_cases", get_active_cases);
        intent.putExtra("death", get_total_death);
        intent.putExtra("recovered_cases", get_recovered_cases);
        startActivity(intent);
    }

    public void country_in_continent(String country_list[]){
        System.out.println("Hello");

        country_spinner = (Spinner) findViewById(R.id.country_spinner);

        final ArrayAdapter<String> countryAdapter = new ArrayAdapter<String>(
                MainActivity.this,
                android.R.layout.simple_list_item_1,
                country_list
        );

        countryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        country_spinner.setAdapter(countryAdapter);

//        country_spinner.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//                if (event.getAction() == MotionEvent.ACTION_UP){
//
//                }
//                return false;
//            }
//        });

        country_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String get_country = countryAdapter.getItem(position).toLowerCase();
                String get_statistics[] = {};

                if ( !get_country.equalsIgnoreCase("...") ) {
                    switch (get_country){
                        case "usa":
                            get_statistics = statistics[0];
                            break;

                        case "canada":
                            get_statistics = statistics[1];
                            break;

                        case "brazil":
                            get_statistics = statistics[2];
                            break;

                        case "colombia":
                            get_statistics = statistics[3];
                            break;

                        case "germany":
                            get_statistics = statistics[4];
                            break;

                        case "france":
                            get_statistics = statistics[5];
                            break;

                        case "vietnam":
                            get_statistics = statistics[6];
                            break;

                        case "india":
                            get_statistics = statistics[7];
                            break;
                    }

                    move_to_covid_19_data(get_statistics, get_country);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        continent_spinner = (Spinner) findViewById(R.id.continent_spinner);


        final ArrayAdapter<String> continentAdapter = new ArrayAdapter<String>(
                MainActivity.this,
                android.R.layout.simple_list_item_1,
                continents
        );

        continentAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        continent_spinner.setAdapter(continentAdapter);

        continent_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String get_continent = continentAdapter.getItem(position).toLowerCase();
                String get_country_list[] = {};
                switch (get_continent){
                    case "north america":
                        get_country_list = countries[0];
                        break;

                    case "south america":
                        get_country_list = countries[1];
                        break;

                    case "europe":
                        get_country_list = countries[2];
                        break;

                    case "asia":
                        get_country_list = countries[3];
                        break;

                    case "choose continent":
                        get_country_list = new String[]{};
                        break;
                }

                country_in_continent(get_country_list);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }
}