package com.example.final_exam_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Covid_19_Data extends AppCompatActivity {
    TextView d_country_name, d_total_cases, d_active_cases, d_death, d_recovered_cases;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_covid_19__data);

        d_country_name = (TextView) findViewById(R.id.country_name);
        d_total_cases = (TextView) findViewById(R.id.all_cases);
        d_active_cases = (TextView) findViewById(R.id.active_cases);
        d_death = (TextView) findViewById(R.id.death);
        d_recovered_cases = (TextView) findViewById(R.id.recovered);

        String total_cases = getIntent().getStringExtra("total_case");
        String active_cases = getIntent().getStringExtra("active_cases");
        String total_death = getIntent().getStringExtra("death");
        String recovered_cases = getIntent().getStringExtra("recovered_cases");
        String country_name = getIntent().getStringExtra("country_name");

        country_name = country_name.substring(0, 1).toUpperCase() + country_name.substring(1);
        d_country_name.setText(country_name);
        d_total_cases.setText(total_cases);
        d_active_cases.setText(active_cases);
        d_death.setText(total_death);
        d_recovered_cases.setText(recovered_cases);
    }
}